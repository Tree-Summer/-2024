#ifndef Good_H_H
#define Good_H_H
class Good{
    public:
        int time,x,y,val;
    Good(){

    };
};
#endif